# Python_PDF_to_MP3
Python script with a GUI interface  to convert PDF file to MP3 or an audio file. 
I recommend you to work on small PDF's preferably within 10 pages. 
You need an internet connection mandatorily to make this work.
AppJar provides an easy way out if you would want to have a gui for simple programs.
pip install the required libraries.






Happpy coding!!!!!!!!!!!!!!!!!
